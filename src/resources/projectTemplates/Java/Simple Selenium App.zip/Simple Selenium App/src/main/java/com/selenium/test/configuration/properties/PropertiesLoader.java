package com.selenium.test.configuration.properties;

import com.selenium.test.configuration.TestsConfig;
import java.lang.reflect.Field;

/**
 * Created by Sidelnikov Mikhail on 18.09.14.
 * Class for loading base tests properties. It gets system properties(by specified names) and sets it to fields of TestConfig object
 */
public class PropertiesLoader {

    /**
     * Sets TestConfig object fields values to specified system properties values
     * @param config {@link com.selenium.test.configuration.TestsConfig} object
     */
    public static void populate(TestsConfig config) {
        Field[] fields = config.getClass().getDeclaredFields();
        for(Field field : fields) {
            Property propertyAnnotation = field.getAnnotation(Property.class);
            if(propertyAnnotation != null){
                String propertyName = propertyAnnotation.value();
                if(propertyName == null) {
                    throw new RuntimeException("Property value cannot be empty. Field name : " + field.getName());
                }
                String propertyValue = System.getProperty(propertyName);
                if(propertyValue != null) {
                    try {
                        field.setAccessible(true);
                        field.set(config, propertyValue);
                    } catch (IllegalAccessException e) {
                        throw new RuntimeException("Field cannot be set...", e);
                    }
                }
            }
        }
    }
}
