package com.selenium.test.pages;

import com.selenium.test.webtestsbase.BasePage;
import com.selenium.test.webtestsbase.WebDriverFactory;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Created by mike-sid on 19.09.14.
 */
public class YouTubePage extends BasePage {

    private static final String PAGE_URL = "http://youtube.com";

    @FindBy(css = "#masthead-search-term")
    private WebElement searchStringElement;

    @Override
    protected void openPage() {
        WebDriverFactory.getDriver().get(PAGE_URL);
    }

    @Override
    public boolean isPageOpened() {
        return searchStringElement.isDisplayed();
    }

    /**
     * inserts search text in search string
     * @param text text for input
     */
    public void insertSearchTest(String text) {
        searchStringElement.sendKeys(text);
    }

    /**
     * clears search string
     */
    private void clearSearchString(){
        searchStringElement.clear();
    }

    /**
     * getting search string text
     * @return text from search string
     */
    public String getSearchStringText(){
        return searchStringElement.getAttribute("value");
    }
}
