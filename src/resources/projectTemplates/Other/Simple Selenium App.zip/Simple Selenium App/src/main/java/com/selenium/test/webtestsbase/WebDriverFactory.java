package com.selenium.test.webtestsbase;

import com.selenium.test.configuration.TestsConfig;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

/**
 * Created by Sidelnikov Mikhail on 18.09.14.
 * Base class for web tests. It contains web driver {@link org.openqa.selenium.WebDriver} instance, used in all tests.
 * All communications with driver should be done through this class
 */
public class WebDriverFactory {
    private static final TestsConfig CONFIG = TestsConfig.getConfig();
    private static WebDriver driver;

    /**
     * Getting of pre-configured {@link org.openqa.selenium.WebDriver} instance.
     * Please use this method only after call {@link #startBrowser() startBrowser} method
     *
     * @return webdriver object, or throw IllegalStateException, if driver has not been initialized
     */
    public static WebDriver getDriver() {
        if (driver != null) {
            return driver;
        } else {
            throw new IllegalStateException("Driver has not been initialized. " +
                    "Please call WebDriverFactory.startBrowser() before use this method");
        }
    }

    /**
     * Main method of class - it initialize driver and starts browser.
     */
    public static void startBrowser() {
        if (driver == null) {
            Browser browser = CONFIG.getBrowser();
            switch (browser) {
                case FIREFOX:
                    driver = new FirefoxDriver(CapabilitiesGenerator.getCapabilities(Browser.FIREFOX));
                    break;
                case CHROME:
                    driver = new ChromeDriver(CapabilitiesGenerator.getCapabilities(Browser.CHROME));
                    break;
                case IE10:
                    driver = new InternetExplorerDriver(CapabilitiesGenerator.getCapabilities(Browser.IE10));
                    break;
                case SAFARI:
                    driver = new SafariDriver(CapabilitiesGenerator.getCapabilities(Browser.SAFARI));
                    break;
                default:
                    throw new IllegalStateException("Unsupported browser type");
            }
        } else {
            throw new IllegalStateException("Driver has already been initialized. Quit it before using this method");
        }
    }

    /**
     * Finishes browser
     */
    public static void finishBrowser() {
        if (driver != null) {
            driver.quit();
        }
    }


}
